Updated: 20200615 - KRS

AquariusTimeSeries - API Wrapped - used to hit the Aquarius Next Generation.

Copy the setup.py and timeseries_client.py files into the Python Environment \Lib\site-packages directory.  This will allow the AquariusTimeSeries.py script to be accessiable in this Python Environment.
